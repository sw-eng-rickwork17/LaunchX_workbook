import * as loggerModule from './logger.js'

console.log(loggerModule)