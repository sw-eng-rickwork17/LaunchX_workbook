import { log } from './logger.js'

log('Hello world')